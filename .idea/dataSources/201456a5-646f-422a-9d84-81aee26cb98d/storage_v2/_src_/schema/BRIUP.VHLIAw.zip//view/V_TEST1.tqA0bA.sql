create view V_TEST1 as
  select "ID","NAME","SALARY" 
from t_user
where id>5
with check option
/

